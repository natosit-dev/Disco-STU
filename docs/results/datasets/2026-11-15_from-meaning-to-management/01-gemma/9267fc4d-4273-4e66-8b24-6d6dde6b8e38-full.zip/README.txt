DiScO STU — COMPLETE PRIVATE STUDY BUNDLE
This contains source text, the pinned human SERA explication, raw test/model requests and responses, human judgments and event histories.
DO NOT publish or commit this ZIP without inspecting its contents.
The model runner never received the Oracle. This export combines evidence AFTER execution for human examination.
SHA-256 manifests detect changed bytes, not semantic accuracy or adversarial tampering. Synthetic fixtures are not model findings; live execution does not prove semantic correctness.
